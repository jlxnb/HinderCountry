package org.eu.pcraft.hindercountry;

import com.destroystokyo.paper.Namespaced;
import io.papermc.paper.event.player.AsyncChatEvent;
import io.papermc.paper.event.player.ChatEvent;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerChatEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.server.ServerLoadEvent;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.metadata.Metadatable;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataHolder;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginLoader;

import javax.xml.stream.events.Namespace;
import java.lang.reflect.Field;

public class EventListener implements Listener {
    @EventHandler
    public void onPlayerCommandPreprocess(PlayerCommandPreprocessEvent event){
        if(StringUtil.isContainEnglish(event.getMessage().substring(1))){
            event.getPlayer().sendMessage(ChatColor.RED+"你没有用中文命令！你不爱国！");
            event.setCancelled(true);
        }
    }
    @EventHandler
    public void onChat(PlayerChatEvent chatEvent){
        String SwearString="我们将坚决抵制英语的无节制蔓延，维护我国语言文化的纯洁性。我们不会让英语成为文化交流的藩篱，也不会让它侵蚀我们的母语环境。我们坚信，语言是文化的载体，保护和传承母语，就是保护我们的根和魂。";
//        NamespacedKey key=new NamespacedKey(HinderCountry.instance,"isSwore");
//        PersistentDataContainer isSwore=chatEvent.getPlayer().getPersistentDataContainer();

        //进服宣誓 由于PDC的对插件名的要求 在此不能使用PDC进行存储 欢迎各位pr其他实现方法

        if(chatEvent.getMessage().equals(SwearString)){
            chatEvent.getPlayer().sendMessage(ChatColor.GREEN+"入服宣誓完成！欢迎加入！");
            //chatEvent.getPlayer().getPersistentDataContainer().set(key,PersistentDataType.INTEGER,1);
        }else{
            chatEvent.getPlayer().sendMessage(ChatColor.RED+"请先入服宣誓！完成宣誓前禁止聊天！");
            chatEvent.getPlayer().sendMessage(ChatColor.RED+"宣誓内容如下：");
            chatEvent.getPlayer().sendMessage(ChatColor.YELLOW+SwearString);
            chatEvent.getPlayer().sendMessage(ChatColor.RED+"请一字不漏（标点完全一致）的在聊天栏发送上面内容！");
        }
        //判断中文聊天
        if(StringUtil.isContainEnglish(chatEvent.getMessage())){
            chatEvent.getPlayer().sendMessage(ChatColor.RED+"你没有用中文聊天！你不爱国！");
            chatEvent.setCancelled(true);
        }
    }
    @EventHandler
    public void onServerLoad(ServerLoadEvent event) throws NoSuchFieldException, IllegalAccessException {
        for(Plugin p:Bukkit.getPluginManager().getPlugins()){
            if(StringUtil.isContainEnglish(p.getName())){
                if(p instanceof HinderCountry){
                    Field f=p.getDescription().getClass().getDeclaredField("name");
                    f.setAccessible(true);
                    f.set(p.getDescription(), "正义的爱国插件");
                    continue;
                }
                Bukkit.getLogger().warning(ChatColor.RED+"检测到邪恶的英文插件！已经改名！！！");
                Field f=p.getDescription().getClass().getDeclaredField("name");
                f.setAccessible(true);
                f.set(p.getDescription(), "一个邪恶的英文插件");
                f=p.getDescription().getClass().getDeclaredField("rawName");
                f.setAccessible(true);
                f.set(p.getDescription(), "一个邪恶的英文插件");
            }
        }
    }

}
