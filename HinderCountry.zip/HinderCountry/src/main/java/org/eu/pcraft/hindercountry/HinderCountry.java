package org.eu.pcraft.hindercountry;

import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.event.Listener;
import org.bukkit.metadata.MetadataValue;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.eu.pcraft.hindercountry.EventListener;

import java.util.HashMap;
import java.util.Map;

public final class HinderCountry extends JavaPlugin  {

//todo:屏蔽物品名,进服宣誓
    static Plugin instance;
    Map<String,String> charMap=new HashMap<>();
    @Override
    public void onEnable() {
        instance=this;
        // Plugin startup logic
        Bukkit.getLogger().info("正在加载碍国插件……");
        Bukkit.getLogger().info("海内存知己，天涯若比邻。");
        Bukkit.getLogger().info("请不要关闭你的服务器……");
        getServer().getPluginManager().registerEvents(new EventListener(),this);
        //if(Bukkit.getServer().get)

    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
    }
}
